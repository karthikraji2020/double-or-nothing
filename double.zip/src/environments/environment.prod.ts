export const environment = {
  production: true,
  APIURL :'https://s3-ap-southeast-1.amazonaws.com/he-public-data/bets7747a43.json'

};
