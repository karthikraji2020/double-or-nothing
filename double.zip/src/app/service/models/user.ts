export class User {
    Name: string;
    Price: string;
    Bet: string;
    ProfileImage: string;
    description?: string;
}
